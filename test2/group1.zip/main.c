#include <stdio.h>
#include <stdlib.h>
#include "heap.h"
#include "vector.h"

/*
 Ако искате компилирайте с MakeFile ако искате просто с gcc main.c heap.c vector.c
 Според мен по-лесно директно с команда
*/

vector_t *create_vector_with_values()
{
    vector_t *v = init_vector();
    push_back(v, 5);
    push_back(v, 13);
    push_back(v, 23);
    push_back(v, 53);
    push_back(v, 56);
    push_back(v, 93);
    push_back(v, 100);
    push_back(v, -14);
    push_back(v, 0);
    push_back(v, 4);
    push_back(v, 55);
    push_back(v, 58);
    push_back(v, 123);

    return v;
}

int find_k_smallest(vector_t *v, int k)
{
}

int main()
{
    vector_t *v = create_vector_with_values();

    heapify(v); // примерен правилен хийп 100 56 58 0 4 123 23 -14 53 13 55 93 5
    printVector(v);

    vector_t *v2 = create_vector_with_values();
    int k = 4;
    printf("Smallest %d in vector: %d", k, find_k_smallest(v2, k)); // 53 е

    clear(v);
    clear(v2);

    return 0;
}

/*
    Напишете тук разсъжденията си за tree sort:

*/