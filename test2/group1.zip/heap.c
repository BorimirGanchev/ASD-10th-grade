#include <stdio.h>
#include "vector.h"

void swap(int *a, int *b)
{
    int temp = *a;
    *a = *b;
    *b = temp;
}

void siftUp(vector_t *v, int i)
{
}

void siftDown(vector_t *v, int i)
{
}

void heapify(vector_t *v)
{
}
