#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

/*
    Коментар обяснение:

*/

int snakesAndLadders(int** board, int N)
{
    return 0;
}

int main()
{
    /*
    [
        [-1, 14, -1, -1, -1, -1],
        [-1,  -1, -1, -1, -1, -1],
        [-1,  31, -1, -1, 12, -1],
        [-1,  -1, -1, -1, -1, -1],
        [-1,  -1, -1, -1, -1, -1],
        [-1,  -1, -1, -1, -1, -1],
    ]
    Should be 4
    */
    printf("%d - example from description\n", snakesAndLadders((int *[]){
        (int[6]){-1, 14, -1, -1, -1, -1},
        (int[6]){-1, -1, -1, -1, -1, -1},
        (int[6]){-1, 31, -1, -1, 12, -1},
        (int[6]){-1, -1, -1, -1, -1, -1},
        (int[6]){-1, -1, -1, -1, -1, -1},
        (int[6]){-1, -1, -1, -1, -1, -1},
    }, 6)); // 4
    /* [
        [-1, 2],
        [-1,-1],
       ]

       Should be 1
    */
    printf("%d - [[-1,2],[-1,-1]]\n", snakesAndLadders((int *[]){
        (int[2]){-1, 2},
        (int[2]){-1, -1},
    }, 2)); // 1

    /*
    [
        [-1, -1, 1],
        [1,  1,  1],
        [1,  1,  -1],
    ]
    Should be impossible: -1
    */
    printf("%d - impossible \n", snakesAndLadders((int *[]){
        (int[3]){-1, -1, 1},
        (int[3]){1, 1, 1},
        (int[3]){1, 1, -1},
    }, 3)); // -1

   return -1
}